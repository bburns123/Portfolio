drop table Customer;
drop table Account;
drop table Transactions;
drop table UserRole;

CREATE TABLE Transactions (
    TransactionID INT NOT NULL,
    AccountNumber INT,
    TransactionDate DATE,
    Description VARCHAR(20),
    Amount DOUBLE

    
);

INSERT INTO Transactions
    (TransactionID, AccountNumber, TransactionDate, Description, Amount)

VALUES
    (1,10101,'2020-04-07','Transaction 1',100),
    (2,10101,'2020-04-07','Transaction 2',-21.95),
    (3,10101,'2020-04-07','Transaction 3',16.25),
    (1,10102,'2020-04-07','Transaction 1',50.00),
    (2,10102,'2020-04-07','Transaction 2',250.00),
    (3,10102,'2020-04-07','Transaction 3',-10.00),
    (1,10201,'2020-04-07','Transaction 1',500.00),
    (2,10201,'2020-04-07','Transaction 2',-50.00),
    (3,10201,'2020-04-07','Transaction 3',25.00),
    (1,10202,'2020-04-07','Transaction 1',49.75),
    (2,10202,'2020-04-07','Transaction 2',16.25),
    (3,10202,'2020-04-07','Transaction 3',-25.0),
    (1,10301,'2020-04-07','Transaction 1',400.00),
    (2,10301,'2020-04-07','Transaction 2',-30.00),
    (3,10301,'2020-04-07','Transaction 3',15.00),
    (1,10302,'2020-04-07','Transaction 1',39.75),
    (2,10302,'2020-04-07','Transaction 2',26.25),
    (3,10302,'2020-04-07','Transaction 3',-15.0);

CREATE TABLE Account (
    AccountNumber INT NOT NULL,
    customerID INT,
    AccountName VARCHAR(100),
    DateOpened DATE,
    AccountType VARCHAR(20),

    PRIMARY KEY(AccountNumber)
);

INSERT INTO Account
    (AccountNumber, customerID, AccountName, DateOpened, AccountType)

VALUES
    (10101,101,'Customer One Checking Account','2020-04-07','Liability'),
    (10102,101,'Customer One Savings Account','2020-04-07','Asset'),
    (10201,102,'Savings Account','2020-04-07','Asset'),
    (10202,102,'Customer Two Credit Card','2020-04-07','Liability'),
    (10301,103,'Savings Account','2020-04-07','Asset'),
    (10302,103,'Customer Three Credit Card','2020-04-07','Liability');


CREATE TABLE Customer (
    CustomerID INT NOT NULL,
    CustomerName VARCHAR(20),
    PhoneNumber INT,
    userID VARCHAR(10),
    Password VARCHAR(10),
    UserRole VARCHAR(10),
    
    PRIMARY KEY(CustomerID)
);

INSERT INTO Customer
    (CustomerID, CustomerName, PhoneNumber, userID, Password, UserRole)

VALUES
    (101,'Customer One',5551212,'Cust1','cust1','User'),
    (102,'Customer Two',4442323,'Cust2','cust2','User'),
    (103,'Customer Three',3334343,'Cust3','cust3','User'),
    (104,'Admin',2224545,'Admin','admin','Admin'),
    (105,'Mgt1',2323482,'Mgt1','mgt1','Mgt');


CREATE TABLE UserRole (
    UserRole VARCHAR(10),
    AccessAccount Boolean,
    AccessUserRole Boolean,
    AccessUsers Boolean
);

INSERT INTO UserRole 
    (UserRole,AccessAccount,AccessUserRole,AccessUsers)

VALUES
    ('Admin', True, True, True),
    ('Mgt', True, False, True),
    ('User', True, False, False);



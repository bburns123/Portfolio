package banking;

import banking.domain.Account;
import banking.domain.Customer;
import banking.domain.Transaction;
import java.util.ArrayList;

/**
 *
 * @author Brendyn Burns
 * This is the Main class
 */
public class BankingSystem {
    public static void main(String[] args) {
        Customer.init();
        Account.init();
        Transaction.init();
        
        ArrayList<Customer> customers = Customer.getCustomers();
        
        for(int i = 0; i < customers.size(); i++){
            System.out.println(customers.get(i));
        }
    }
}

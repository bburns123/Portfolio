package banking.database;

import banking.database.BankingSystemDA;
import banking.domain.Account;
import banking.domain.Asset;
import banking.domain.Liability;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.TypedQuery;

/**
 *
 * @author Brendyn Burns
 * This is the database class for Account
 */
public class AccountDA {
    
    //ArrayList for accounts
    
    public static ArrayList<Account> accounts = new ArrayList<Account>(5);
    
    //add method appends an account to the accounts ArrayList
    
    public static void add(Account acc) {
        accounts.add(acc);
    }
    
    //ArrayList getCustomerAccounts, takes customerID input
    //creates arrayList customerAccounts
    
    //loops through accounts arrayList and for each account == customerID,
    //appends account to customerAccount arrayList
    
    public static ArrayList<Account> getCustomerAccounts(int custID) {
        Account acc = null;
        ArrayList<Account> items = null;
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        
        String sql = "SELECT a FROM Account a " +
                     "WHERE a.customerID = :id";
        
        TypedQuery<Account> query = em.createQuery(sql,Account.class);
        query.setParameter("id", custID);

        try {
            List itemList = query.getResultList();
            items = new ArrayList<>(itemList);
            System.out.println(items.get(0));
        }
        catch(Exception e) {
            Exception ex = new Exception("x");
            System.out.println(e);
        }
        finally {
           em.close();
        }
        
        return items;
        
        
        
        /**
         * Account acc;
        ArrayList<Account> customerAccounts = new ArrayList<Account>(5);
        
        for(int i = 0; i < accounts.size(); i++) {
            acc = accounts.get(i);
            if (acc.getCustomerID() == custID)
                customerAccounts.add(acc);
        }
        
        return customerAccounts;
        */
    }
    
    
     public static void init(){
         /**
         if (accounts.size() <= 0) {
            Account a;
            Connection connection;
            Statement statement;
            ResultSet rs;
            String sql;
             
             try {
                connection = (Connection) DriverManager.getConnection("jdbc:derby://localhost:1527/BankingSystemDB","CIS640","cis640");
                sql = "Select * FROM Account";
                System.out.println(connection);
                
                statement = connection.createStatement();
                rs = statement.executeQuery(sql);
                
                while (rs.next()) {
                    a = new Account() {};
                    Account c;
                    a.setAccountType(rs.getString(5));
                    
                    if (a.accountType.equals("Asset")) {
                        c = new Asset();
                        c.setAccountNumber(rs.getInt(1));
                        c.setCustomerID(rs.getInt(2));
                        c.setAccountName(rs.getString(3));
                        c.setDateOpened(rs.getDate(4));
                        c.setAccountType(rs.getString(5));
                        c.add();
                    }
                    else {
                        c = new Liability();
                        c.setAccountNumber(rs.getInt(1));
                        c.setCustomerID(rs.getInt(2));
                        c.setAccountName(rs.getString(3));
                        c.setDateOpened(rs.getDate(4));
                        c.setAccountType(rs.getString(5));
                        c.add();
                    }
                    
                }
                
             }
             catch(Exception e) {
                 
             }
             */
         }
         
         /**
        Account a;
        Date today = new Date();
        
        a = new Asset();
        a.setAccountNumber(10101);
        a.setCustomerID(101);
        a.setAccountName("Customer One Checking Account");
        a.setDateOpened(today);
        a.setAccountType("Liability");
        a.add();
        
        a = new Asset();
        a.setAccountNumber(10102);
        a.setCustomerID(101);
        a.setAccountName("Customer One Savings Account");
        a.setDateOpened(today);
        a.setAccountType("Asset");
        a.add();
        
        a = new Asset();
        a.setAccountNumber(10201);
        a.setCustomerID(102);
        a.setAccountName("Savings Account");
        a.setAccountType("Asset");
        a.setDateOpened(today);
        a.add();
        
        a = new Liability();
        a.setAccountNumber(10202);
        a.setCustomerID(102);
        a.setAccountName("Customer Two Credit Card");
        a.setDateOpened(today);
        a.setAccountType("Liability");
        a.add();
        
        a = new Asset();
        a.setAccountNumber(10301);
        a.setCustomerID(103);
        a.setAccountName("Savings Account");
        a.setAccountType("Asset");
        a.setDateOpened(today);
        a.add();
        
        a = new Liability();
        a.setAccountNumber(10302);
        a.setCustomerID(103);
        a.setAccountName("Customer Three Credit Card");
        a.setDateOpened(today);
        a.setAccountType("Liability");
        a.add();
        
        */
    }


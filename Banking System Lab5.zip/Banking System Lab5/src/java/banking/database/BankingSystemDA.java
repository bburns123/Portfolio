package banking.database;

import java.sql.Connection;
import java.sql.DriverManager;
import banking.BankingSystem;
/**
 *
 * @author Brendyn Burns
 */
public class BankingSystemDA {
    /**
    private static Connection connection=null;
    private BankingSystemDA(){}
    public static Connection getConnection(){
        if (connection == null) {
            try{connection = (Connection)
                DriverManager.getConnection("jdbc:derby://localhost:1527/BankingSystemDB","CIS640","cis640");
                
                    }
            
            catch(Exception e) {
                System.out.println(e.getMessage());
            }
            return connection;
            */
}


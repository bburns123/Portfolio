package banking.database;

import banking.domain.Customer;
import banking.exceptions.LoginException;
import banking.exceptions.PassException;
import java.util.ArrayList;
import banking.servlets.LoginServlet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author Brendyn Burns
 * This is the database class for Customer
 */
public class CustomerDA {
    //Creates customers and getCustomers ArrayLists
    
    private static ArrayList<Customer> customers = new ArrayList<Customer>(5);
    
    public static ArrayList<Customer> getCustomers() {
        return customers;
    }
    
    //adds a customer to customers arrayList
    
    public static void add(Customer c) {
        customers.add(c);
    }
    
    //needs to throw an exception
    //c.getUserID().equals(uid) && c.getPassword().equals(pass)
    
    public static Customer find(String uid, String pass) throws LoginException, PassException, Exception {
        Customer c = null;
        System.out.println("UID = " + uid + "Pass = " + pass);
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        
        String sql = "SELECT c FROM Customer c " +
                     "WHERE c.userID = :u";
        
        TypedQuery<Customer> query = em.createQuery(sql,Customer.class);
        query.setParameter("u", uid);
        System.out.println("Query = " + query);
        
        try {
            c = query.getSingleResult();
            System.out.println(c);
        }
        catch(Exception e) {
            System.out.println("Exception =  " + e);
            LoginException ex = new LoginException("x");
            throw ex;
        }
        
        finally {
           em.close();
        }
        return c;
        
        /*
        Customer c;
        System.out.println(customers);
        for (int i = 0; i < customers.size(); i++) {
            c = customers.get(i);
            System.out.println("uid: " + uid + "pass: " + pass);
        
            boolean userIdEquals = c.getUserID().equals(uid);
            boolean passEquals = c.getPassword().equals(pass);
            
            if (userIdEquals && passEquals){
                return c;
            }
            
            if (userIdEquals == false && passEquals == true) {
                throw new LoginException("x");
            }
            if (passEquals == false && userIdEquals == true){
                throw new PassException("y");
            }
         
            throw new Exception("");
        */
    }
        
    
    public static void init() {
       /*
        * 
        if (customers.size() <= 0) {
            Customer c;
            Connection connection;
            Statement statement;
            ResultSet rs;
            String sql;
             
             try {
                connection = (Connection) DriverManager.getConnection("jdbc:derby://localhost:1527/BankingSystemDB","CIS640","cis640");
                sql = "Select * From Customer";
                System.out.println(connection);
                
                statement = connection.createStatement();
                rs = statement.executeQuery(sql);
                
                while (rs.next()) {
                    c = new Customer();
                    c.setCustomerID(rs.getInt(1));
                    c.setName(rs.getString(2));
                    c.setPhoneNumber(rs.getInt(3));
                    c.setUserID(rs.getString(4));
                    c.setPassword(rs.getString(5));
                    c.add();
                }
                
             }
             catch(Exception e) {
                 
             }
             * 
             */
         }
        
        
        /**
         * Customer c;
        
        c = new Customer();
        c.setCustomerID(101);
        c.setName("Customer One");
        c.setPhoneNumber(5551212);
        c.setUserID("Cust1");
        c.setPassword("cust1");
        c.add();
        
        c = new Customer();
        c.setCustomerID(102);
        c.setName("Customer Two");
        c.setPhoneNumber(4442323);
        c.setUserID("Cust2");
        c.setPassword("cust2");
        c.add();
        
        c = new Customer();
        c.setCustomerID(103);
        c.setName("Customer Three");
        c.setPhoneNumber(3334343);
        c.setUserID("Cust3");
        c.setPassword("cust3");
        c.add();
        */
    }

package banking.database;

/**
 *
 * @author Brendyn Burns
 */
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("Banking_System_Lab4PU");
    
    public static EntityManagerFactory getEmFactory() {
        return emf;
    }
}

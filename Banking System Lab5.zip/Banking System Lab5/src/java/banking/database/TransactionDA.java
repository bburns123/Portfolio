
package banking.database;

import banking.domain.Transaction;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author Brendyn Burns
 * This is the database class for Transaction
 */
public class TransactionDA {
    //Creates transactions ArrayList
    private static ArrayList<Transaction> transactions = new ArrayList<Transaction>(5);
    
    //add takes a Transaction as an input
    //sets a transactionID to trans by taking the list size and adding 1 
    //(in case transactions.size = 0)
    //appends to transactions arrayList
    
    public static void add(Transaction trans) {
        trans.setTransactionID(transactions.size() + 1);
        transactions.add(trans);
    }
    
    //Creates getAccountTransaction and takes in accountNumber as input
    //Creates accountTransactions arrayList
    //loops through transactions, if accountNumber == transaction accountNumber,
    //appends to accountTransactions arrayList and returns it
    
    public static ArrayList<Transaction> getAccountTransactions(int accNo){
        Transaction trans = null;
        ArrayList<Transaction> items = null;
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        
        String sql = "SELECT t FROM Transaction t " +
                     "WHERE t.accountNumber = :accNo";
        
        TypedQuery<Transaction> query = em.createQuery(sql,Transaction.class);
        query.setParameter("accNo", accNo);
        
        try {
            List itemList = query.getResultList();
            items = new ArrayList<>(itemList);
            System.out.println(items.get(0));
        }
        catch(Exception e) {
            Exception ex = new Exception("x");
            System.out.println(e);
        }
        
        finally {
           em.close();
        }
        return items;
        
        
        
        /**
        for (int i = 0; i < transactions.size(); i++) {
            trans = transactions.get(i);
            if (accNo == trans.getAccountNumber())
                accountTransactions.add(trans);
        }
        return accountTransactions;
        */
    }
    
    public static void init() {
        /** if (transactions.size() <= 0) {
            Transaction t;
            Connection connection;
            Statement statement;
            ResultSet rs;
            String sql;
             
             try {
                connection = (Connection) DriverManager.getConnection("jdbc:derby://localhost:1527/BankingSystemDB","CIS640","cis640");
                sql = "Select * FROM Transactions";
                System.out.println(connection);
                
                statement = connection.createStatement();
                rs = statement.executeQuery(sql);
                
                while (rs.next()) {
                    t = new Transaction();
                    t.setTransactionID(rs.getInt(1));
                    t.setAccountNumber(rs.getInt(2));
                    t.setTransactionDate(rs.getDate(3));
                    t.setDescription(rs.getString(4));
                    t.setAmount(rs.getInt(5));
                    t.add();
                }
                
             }
             catch(Exception e) {
                 
             }
             */
         }
        
        /**
         * Transaction t;
        Date today = new Date();
        
        //Customer 1
        
        t = new Transaction();
        t.setAccountNumber(10101);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(100);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10101);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(-21.95);
        t.setTransactionID(2);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10101);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(16.25);
        t.setTransactionID(3);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10102);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(50.00);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10102);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(250.00);
        t.setTransactionID(2);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10102);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(-10.00);
        t.setTransactionID(3);
        t.add();
        
        //Customer 2
        
        t = new Transaction();
        t.setAccountNumber(10202);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(500.00);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10202);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(-50.00);
        t.setTransactionID(2);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10202);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(25.00);
        t.setTransactionID(3);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10201);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(49.75);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10201);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(16.25);
        t.setTransactionID(2);
        t.setTransactionID(3);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10201);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(-25.0);
        t.add();
        
        //customer 3
        
        t = new Transaction();
        t.setAccountNumber(10302);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(400.00);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10302);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(-30.00);
        t.setTransactionID(2);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10302);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(15.00);
        t.setTransactionID(3);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10301);
        t.setTransactionDate(today);
        t.setDescription("Transaction 1");
        t.setAmount(39.75);
        t.setTransactionID(1);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10301);
        t.setTransactionDate(today);
        t.setDescription("Transaction 2");
        t.setAmount(26.25);
        t.setTransactionID(2);
        t.setTransactionID(3);
        t.add();
        
        t = new Transaction();
        t.setAccountNumber(10301);
        t.setTransactionDate(today);
        t.setDescription("Transaction 3");
        t.setAmount(-15.0);
        t.add();
        */
    }


package banking.domain;

import banking.database.AccountDA;
import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Brendyn Burns
 * This is the Account class, which associates different accounts to a customer
 */
@Entity
public class Account {
    private int customerID;
    @Id
    private int accountNumber;
    private String accountName;
    private Date dateOpened;
    public String accountType;
    
    //ArrayLists for CustomerAccounts and Transactions
    
    public static ArrayList<Account> getCustomerAccounts(int custID) {
        return AccountDA.getCustomerAccounts(custID);
    }
    
    public ArrayList<Transaction> getTransactions() {
        return Transaction.getAccountTransactions(accountNumber);
    }
    
    //Methods from AccountDA
    
    public void add() {
        AccountDA.add(this);
    }
    
    public static void init() {
        AccountDA.init();
    }
    
    //Getter and Setter Methods
    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Date getDateOpened() {
        return dateOpened;
    }

    public void setDateOpened(Date dateOpened) {
        this.dateOpened = dateOpened;
    }
    
    //Account toString method
    //Creates the transactions arrayList and sets it equal to getTransactions arrayList
    //Returns accountNumber, accountName, and dateOpened
    //The loop sets sum to each transaction amount and returns each transaction and amount
    
    public String toString() {
        ArrayList<Transaction> transactions = getTransactions();
        double sum = 0.0;
        
        String returnString = "Account: " + accountNumber + " " + accountName + " " + dateOpened + " " + accountType;
        for (int i = 0; i < transactions.size(); i++){
            sum = sum+= transactions.get(i).getAmount();
            returnString = returnString + "\n          " + transactions.get(i) + "  " + sum;
        }
        
        return returnString;
    }
}

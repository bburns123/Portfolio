package banking.domain;

/**
 *
 * @author Brendyn Burns
 * This is the Asset class, it is a sub-class to account
 * Each account has a liability account and an asset account
 */
public class Asset extends Account {
    
}

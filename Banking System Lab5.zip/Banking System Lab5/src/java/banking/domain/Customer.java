package banking.domain;

import banking.database.CustomerDA;
import banking.domain.Account;
import banking.exceptions.LoginException;
import banking.exceptions.PassException;
import java.util.ArrayList;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Brendyn Burns
 * This is the Customer class, it creates a customer and takes in information
 * from the Account class, and furthers into Transaction class information
 */
@Entity
public class Customer {
    @Id
    private int customerID;
    private int phoneNumber;
    @Column(name="CustomerName")
    private String name;
    private String userID;
    private String password;
    private String UserRole;
    
    //LoginException
    
    public static Customer login(String uid, String pass) throws LoginException, PassException, Exception {
        //try block
        Customer c = null;
        try {
            System.out.println(uid + pass);
            c = CustomerDA.find(uid, pass);
            System.out.println(c);
            if (c.getPassword().equals(pass)){}
            else {
                throw new PassException("y");
            }
            //see if it returns before throwing exception
        }
        catch (LoginException e) {
            throw new LoginException("Incorrect User ID or Password!");
            
        }
        catch (PassException e) {
            throw new PassException("y");
        }
        catch (Exception e) {
            System.out.println(e);
            throw new Exception("x");
            
        }
        return c;
        //return New Customer();
    }
    
    //ArrayList for getCustoemrs and getAccounts
    
    public static ArrayList<Customer> getCustomers() {
        return CustomerDA.getCustomers();
    }
    
    public ArrayList<Account> getAccounts() {
        return Account.getCustomerAccounts(customerID);
    }
    
    //init and add methods from CustomerDA
    
    public static void init() {
        CustomerDA.init();
    }
    
    public void add() {
        CustomerDA.add(this);
    }
    
    public static void add(Customer c) {
        CustomerDA.add(c);
    }
    
    //Getter and Setter Methods
    public String getUserRole() {
        return UserRole;
    }

    public void setUserRole(String UserRole) {
        this.UserRole = UserRole;
    }
    
    
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    //toString Method
    //sets customerString to get customerID and name
    //gets accounts and appends them to customerString
    
    public String toString() {
        String customerString = "\nCustomer " + customerID + " " + name;
        ArrayList<Account> accounts = getAccounts();
        
        for (int i = 0; i < accounts.size(); i++) {
            customerString = customerString + "\n     " + accounts.get(i);
        }
        
        return customerString;
    }
}

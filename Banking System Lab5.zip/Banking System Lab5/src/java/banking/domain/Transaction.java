package banking.domain;

import banking.database.TransactionDA;
import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Brendyn Burns
 * This is the Transaction class, which associates different transactions to
 * a specific account
 */
@Entity
@Table(name = "Transactions")
public class Transaction {
    @Id
    private int transactionID;
    private int accountNumber;
    private double amount;
    private String description;
    private Date transactionDate;

    //getAccountTransactions arrayList
    //Takes accountNumber as input
    
    public static ArrayList<Transaction> getAccountTransactions(int accNo) {
        return TransactionDA.getAccountTransactions(accNo);
    }
    
    //methods from TransactionDA
    
    public void add() {
        TransactionDA.add(this);
    }
    
    public static void init() {
        TransactionDA.init();
    }
    
    //Getter and Setter methods
    
    public int getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }
    
    //Transaction toString method
    //returns transactionID, transactionDate, description, and amount
    
    public String toString() {
        return "" + transactionID + " " + transactionDate + " " + description + "  " + amount;
    }
}

package banking.exceptions;

/**
 *
 * @author Brendyn Burns
 * This is an exception to verify the username during login
 */
public class LoginException extends Exception {
    public LoginException (String msg) {
        super(msg);
    }
}

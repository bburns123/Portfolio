package banking.exceptions;

/**
 *
 * @author Brendyn Burns
 * This is an exception to verify the password during login
 */
public class PassException extends Exception {
    public PassException (String msg) {
        super(msg);
    }
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking.servlets;

import banking.database.DBUtil;
import banking.domain.Customer;
import banking.database.CustomerDA;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Brendyn Burns
 */
public class AdminServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ServletContext sc = getServletContext();
        HttpSession session = request.getSession();
        
        String Name = request.getParameter("name");
        String custID = request.getParameter("custID");
        String phoneNum = request.getParameter("phoneNumber");
        String userID = request.getParameter("userID");
        String password = request.getParameter("password");
        String userRole = request.getParameter("userRole");
        
        
        int customerId = Integer.parseInt(custID);
        int phoneNumber = Integer.parseInt(phoneNum);
        
        Customer c = new Customer();
        c.setCustomerID(customerId);
        c.setName(Name);
        c.setPassword(password);
        c.setPhoneNumber(phoneNumber);
        c.setUserID(userID);
        c.setUserRole(userRole);
        
        ArrayList<Customer> customers = null;
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String sql = "SELECT c FROM Customer c " +
                     "WHERE c.userID = :u";
        
        TypedQuery<Customer> query = em.createQuery(sql,Customer.class);
        query.setParameter("u", userID);
        
        String errorMsg = null;
        
        try {
            Customer cust = new Customer();
            
            System.out.println("Inside Try Block Servlet");
            
            List itemList = query.getResultList();
            customers = new ArrayList<>(itemList);
            for(int i = 0; i < customers.size(); i++) {
                cust = customers.get(i);
                if (cust.getCustomerID() == c.getCustomerID()) {
                    errorMsg = "Unavailable Customer ID";
                } 
                else {
                    em.persist(c);
                    errorMsg = "Success";
                }
            }
        }
        catch (Exception e) {
            System.out.println("Hit an exception when reaching servlet try-statement");
        }
        finally {
            em.close();
        }
        String url = "Admin.jsp";
        request.setAttribute("errorMsg", errorMsg);
        
        RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }

    


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

package banking.servlets;

import static banking.database.AccountDA.accounts;
import banking.domain.Account;
import banking.domain.Customer;
import banking.domain.Transaction;
import banking.exceptions.LoginException;
import banking.exceptions.PassException;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Brendyn Burns
 * This is the LoginServlet class, this class verifies a user's login by throwing
 * exceptions if a username or password is incorrect and showing the user error
 * messages accordingly.
 * 
 * After successful login, the page is redirected to "loginSuccess.jsp" and is
 * sent variables to the session.
 */
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        //Customers, Accounts, and Transactions are initialized at start in web.xml
        
        //Sets variables
        String url = "/index.html";
        String errorMsg = "";
        String password = request.getParameter("Password"); 
        String userID = request.getParameter("Username");
        
        Customer customer = new Customer();
        
        //Try - Catch statement to verify login
        try {
            customer = Customer.login(userID, password);
            url = "/loginSuccess.jsp";
            errorMsg = "";
            
            
        }
        catch(LoginException e){
            errorMsg = "Incorrect username";
            url = "/login.jsp";
        }
        catch(PassException e) {
            errorMsg = "Incorrect Password";
            url = "/login.jsp";
        }
        catch(Exception e) {
            errorMsg = "Incorrect username and password";
            url = "/login.jsp";
            System.out.println(e);
        }
        finally {
            System.out.println(customer);
            ArrayList<Account> accounts = customer.getAccounts();
            String userRole = customer.getUserRole();
            

            //Attribute setters
            request.setAttribute("userRole", userRole);
            request.setAttribute("customer", customer);
            request.setAttribute("name", userID);
            session.setAttribute("message", errorMsg);
            session.setAttribute("account", accounts);


            //Requests
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

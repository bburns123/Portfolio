package banking.servlets;

import banking.domain.Account;
import banking.domain.Customer;
import banking.domain.Transaction;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Brendyn Burns
 * This is the accountHandlingServlet, it directs the buttons from loginSuccess.jsp
 * to the accountBalance.jsp, as well as the table setup and moves data into the
 * accountBalance.jsp
 */
public class accountHandlingServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ServletContext sc = getServletContext();
        HttpSession session = request.getSession();
        
        //Creates variables for a specific account and sets the url
        
        String url = "accountBalance.jsp";
        Transaction transactions = new Transaction();
        
        String accType = request.getParameter("accType");
        String accName = request.getParameter("accName");
        String accDate = request.getParameter("accDate");
        String accNumber = request.getParameter("accNumber");
        
        //Converts the account number into an integer
        
        int accNo = Integer.parseInt(accNumber);
        
        //retrieves an account's transactions
        
        ArrayList<Transaction> trans = transactions.getAccountTransactions(accNo);
        
        //setAttributes
        
        request.setAttribute("trans", trans);
        request.setAttribute("accNumber", accNumber);
        request.setAttribute("accName", accName);
        request.setAttribute("accDate", accDate);
        request.setAttribute("accType", accType);
        

        RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

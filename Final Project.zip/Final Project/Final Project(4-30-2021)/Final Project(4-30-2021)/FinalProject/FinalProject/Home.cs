﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Home : Form
    {
        Login frmLogin;

        public Home(Login F2)
        {
            InitializeComponent();
            this.frmLogin = F2;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login f1 = new Login();
            f1.Show();
        }

        private void btnSearch1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FindAMusician f1 = new FindAMusician(frmLogin);
            f1.Show();
        }

        private void btnSearch2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search2 f1 = new Search2(frmLogin);
            f1.Show();
        }

        private void btnSearch3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search3 f1 = new Search3(frmLogin);
            f1.Show();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Hide();
            Insert f1 = new Insert(frmLogin);
            f1.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update f1 = new Update(frmLogin);
            f1.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete f1 = new Delete(frmLogin);
            f1.Show();
        }
    }
}

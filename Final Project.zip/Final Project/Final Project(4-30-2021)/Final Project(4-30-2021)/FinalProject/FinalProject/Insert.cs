﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Insert : Form
    {
        Login frmLogin;
        public Insert(Login F2)
        {
            InitializeComponent();
            frmLogin = F2;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home f1 = new Home(frmLogin);
            f1.Show();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            String ConnectString = frmLogin.ConnectionString();
            SqlConnection OpenConnection = new SqlConnection(ConnectString);
            SqlDataAdapter MusicianAdapter = new SqlDataAdapter();
            DataSet MusicianDataSet = new DataSet();

            MusicianAdapter.SelectCommand = new SqlCommand();
            MusicianAdapter.SelectCommand.Connection = OpenConnection;

            MusicianAdapter.SelectCommand.CommandText = "Insert into Musician values (@SIN, @FirstName, @LastName, @Instrument, @Email)";
            MusicianAdapter.SelectCommand.Parameters.AddWithValue("@SIN", txtSin.Text);
            MusicianAdapter.SelectCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
            MusicianAdapter.SelectCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
            MusicianAdapter.SelectCommand.Parameters.AddWithValue("@Instrument", txtInstrument.Text);
            MusicianAdapter.SelectCommand.Parameters.AddWithValue("@Email", txtEmail.Text);

            try
            {
                OpenConnection.Open();
                MusicianAdapter.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("Successful");

                MusicianAdapter.SelectCommand.CommandText = "Select * from Musician";
                MusicianAdapter.Fill(MusicianDataSet, "newMusician");
                dgvResults.AutoGenerateColumns = true;
                dgvResults.DataSource = MusicianDataSet;
                dgvResults.DataMember = "newMusician";
                
                dgvResults.Show();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }




            OpenConnection.Close();
        }

        private void Insert_Load(object sender, EventArgs e)
        {
            dgvResults.Hide();
        }
    }
}

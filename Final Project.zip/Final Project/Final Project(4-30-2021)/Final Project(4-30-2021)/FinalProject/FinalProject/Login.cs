﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public string ConnectionString()
        {
            string SQLServerConnectionString;
            string SeverName, DatabaseName, UserID, Password;

            SeverName = txtSeverName.Text;
            DatabaseName = txtDatabaseName.Text;
            UserID = txtUserID.Text;
            Password = txtPassword.Text;

            SQLServerConnectionString = "Data Source = " + SeverName + "; Initial Catalog = " + DatabaseName + "; " +
                "User ID = " + UserID + "; Password = " + Password + "; ";

            return SQLServerConnectionString;
        }

        public bool CheckConnection()
        {
            String ConnectString = ConnectionString();
            SqlConnection Connection = new SqlConnection(ConnectString);
            bool Test = false;

            try
            {
                Connection.Open();
                Test = true;
                Connection.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                Test = false;
                Connection.Close();
            }


            // Once the test is complete, it will return the boolean value
            return Test;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            {
                bool ConnectionOpenned;

                ConnectionOpenned = CheckConnection();

                if (ConnectionOpenned)
                {
                    this.Hide();
                    Home F1 = new Home(this);
                    F1.Show();
                }
                else
                {
                    lblErrorMessage.Show();
                    lblErrorMessage.Text = "Wrong Combination";
                }

            }
        }
    }
}

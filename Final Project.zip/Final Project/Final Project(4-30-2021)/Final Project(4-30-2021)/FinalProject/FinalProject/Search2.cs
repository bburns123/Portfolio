﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Search2 : Form
    {
        Login frmLogin;

        public Search2(Login F2)
        {
            InitializeComponent();
            frmLogin = F2;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home f1 = new Home(frmLogin);
            f1.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            String ConnectString = frmLogin.ConnectionString();

            SqlConnection OpenConnection = new SqlConnection(ConnectString);
            SqlDataAdapter SearchAdapter = new SqlDataAdapter();
            DataSet SearchDataSet = new DataSet();

            SearchAdapter.SelectCommand = new SqlCommand();
            SearchAdapter.SelectCommand.Connection = OpenConnection;


            //Input SQL Multiple Table Search Command Here
            SearchAdapter.SelectCommand.CommandText = "select m.FirstName, m.LastName, s.Title, s.YearRecorded, ms.NumberSold from Song s , Artist a,MusicianHasArtist mha , Musician m , MonthlySales ms , SongHasWriter shw , Writer w where s.ArtistName = a.Name and a.ArtistID=mha.ArtistID and mha.MusicianSIN=m.Sin and shw.ISRC=s.ISRC and shw.WriterSin=w.Sin and ms.ISRC=s.ISRC and m.FirstName = '"+ txtMusicianFirstName.Text +"' and m.LastName = '"+ txtMusicianLastName.Text +"';";

            OpenConnection.Open();

            SearchAdapter.Fill(SearchDataSet, "Search_Results");
            dgvResults.AutoGenerateColumns = true;
            dgvResults.DataSource = SearchDataSet;
            dgvResults.DataMember = "Search_Results";

            OpenConnection.Close();
        }
    }
}

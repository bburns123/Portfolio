package com.brendyn.lifecounter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class LifeCounterActivity extends AppCompatActivity {
    int player;


    private int p1Counter = 40;
    private int p2Counter = 40;
    private int p3Counter = 40;
    private int p4Counter = 40;
    private int p5Counter = 40;
    private int p6Counter = 40;
    private int p7Counter = 40;
    private int p8Counter = 40;

    public int p1Commander = 0;
    public int p2Commander = 0;
    public int p3Commander = 0;
    public int p4Commander = 0;
    public int p5Commander = 0;
    public int p6Commander = 0;
    public int p7Commander = 0;
    public int p8Commander = 0;

    public int p1Commander2 = 0;
    public int p2Commander2 = 0;
    public int p3Commander2 = 0;
    public int p4Commander2 = 0;
    public int p5Commander2 = 0;
    public int p6Commander2 = 0;
    public int p7Commander2 = 0;
    public int p8Commander2 = 0;

    public int p1Commander3 = 0;
    public int p2Commander3 = 0;
    public int p3Commander3 = 0;
    public int p4Commander3 = 0;
    public int p5Commander3 = 0;
    public int p6Commander3 = 0;
    public int p7Commander3 = 0;
    public int p8Commander3 = 0;

    public int p1Commander4 = 0;
    public int p2Commander4 = 0;
    public int p3Commander4 = 0;
    public int p4Commander4 = 0;
    public int p5Commander4 = 0;
    public int p6Commander4 = 0;
    public int p7Commander4 = 0;
    public int p8Commander4 = 0;

    public int p1Infect = 0;
    public int p2Infect = 0;
    public int p3Infect = 0;
    public int p4Infect = 0;
    public int p5Infect = 0;
    public int p6Infect = 0;
    public int p7Infect = 0;
    public int p8Infect = 0;

    public int p1Energy = 0;
    public int p2Energy = 0;
    public int p3Energy = 0;
    public int p4Energy = 0;
    public int p5Energy = 0;
    public int p6Energy = 0;
    public int p7Energy = 0;
    public int p8Energy = 0;

    public int p1Storm = 0;
    public int p2Storm = 0;
    public int p3Storm = 0;
    public int p4Storm = 0;
    public int p5Storm = 0;
    public int p6Storm = 0;
    public int p7Storm = 0;
    public int p8Storm = 0;

    private View decorView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                if (visibility == 0)
                    decorView.setSystemUiVisibility(hideSystemBars());
            }
        });

        setContentView(R.layout.activity_life_counter);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //Getting the format and players selected from the MainActivity
        Intent getterIntent = getIntent();
        String format = getterIntent.getStringExtra("format");
        String players = getterIntent.getStringExtra("players");

        //Initializing Life Counter Text Views
        TextView txtPlayer1 = findViewById(R.id.txtPlayer1);
        TextView txtPlayer2 = findViewById(R.id.txtPlayer2);
        TextView txtPlayer3 = findViewById(R.id.txtPlayer3);
        TextView txtPlayer4 = findViewById(R.id.txtPlayer4);
        TextView txtPlayer5 = findViewById(R.id.txtPlayer5);
        TextView txtPlayer6 = findViewById(R.id.txtPlayer6);
        TextView txtPlayer7 = findViewById(R.id.txtPlayer1_2);
        TextView txtPlayer8 = findViewById(R.id.txtPlayer2_2);

        //if statement to set starting life totals
        if (format.equals("Standard")) {
            txtPlayer1.setText("20");
            txtPlayer2.setText("20");
            txtPlayer3.setText("20");
            txtPlayer4.setText("20");
            txtPlayer5.setText("20");
            txtPlayer6.setText("20");
            txtPlayer7.setText("20");
            txtPlayer8.setText("20");

            p1Counter = 20;
            p2Counter = 20;
            p3Counter = 20;
            p4Counter = 20;
            p5Counter = 20;
            p6Counter = 20;
            p7Counter = 20;
            p8Counter = 20;

        }

        //Reset Button
        Button btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (format.equals("Standard")) {
                    txtPlayer1.setText("20");
                    txtPlayer2.setText("20");
                    txtPlayer3.setText("20");
                    txtPlayer4.setText("20");
                    txtPlayer5.setText("20");
                    txtPlayer6.setText("20");
                    txtPlayer7.setText("20");
                    txtPlayer8.setText("20");

                    p1Counter = 20;
                    p2Counter = 20;
                    p3Counter = 20;
                    p4Counter = 20;
                    p5Counter = 20;
                    p6Counter = 20;
                    p7Counter = 20;
                    p8Counter = 20;

                } else {

                    txtPlayer1.setText("40");
                    txtPlayer2.setText("40");
                    txtPlayer3.setText("40");
                    txtPlayer4.setText("40");
                    txtPlayer5.setText("40");
                    txtPlayer6.setText("40");
                    txtPlayer7.setText("40");
                    txtPlayer8.setText("40");

                    p1Counter = 40;
                    p2Counter = 40;
                    p3Counter = 40;
                    p4Counter = 40;
                    p5Counter = 40;
                    p6Counter = 40;
                    p7Counter = 40;
                    p8Counter = 40;
                }
            }
        });

        //Initializing player views
        LinearLayout vPlayer1 = findViewById(R.id.vPlayer1);
        LinearLayout vPlayer1_2 = findViewById(R.id.vh1);
        LinearLayout vPlayer2 = findViewById(R.id.vPlayer2);
        LinearLayout vPlayer3 = findViewById(R.id.vh2);
        LinearLayout vPlayer4 = findViewById(R.id.vPlayer4);
        LinearLayout vPlayer5 = findViewById(R.id.vh3);
        LinearLayout vPlayer6 = findViewById(R.id.vPlayer6);

        LinearLayout vPlayer7 = findViewById(R.id.vh1_2);
        LinearLayout vPlayer8 = findViewById(R.id.vh2_2);

        //if statement to set starting players
        if (players.equals("2")) {
            vPlayer5.setVisibility(View.GONE);
            vPlayer2.setVisibility(View.GONE);
            vPlayer4.setVisibility(View.GONE);
            vPlayer1.setVisibility(View.GONE);
            vPlayer1_2.setVisibility(View.GONE);
            vPlayer6.setVisibility(View.GONE);
            vPlayer3.setVisibility(View.GONE);

            vPlayer7.setVisibility(View.VISIBLE);
            vPlayer8.setVisibility(View.VISIBLE);
        } else if (players.equals("3")) {
            vPlayer5.setVisibility(View.GONE);
            vPlayer4.setVisibility(View.GONE);
            vPlayer3.setVisibility(View.GONE);

            vPlayer8.setVisibility(View.VISIBLE);
        } else if (players.equals("4")) {
            vPlayer5.setVisibility(View.GONE);
        } else if (players.equals("5")) {
            vPlayer6.setVisibility(View.GONE);
            vPlayer5.setVisibility(View.GONE);

            vPlayer8.setVisibility(View.VISIBLE);
        } else if (players.equals("1")) {
            vPlayer2.setVisibility(View.GONE);
            vPlayer5.setVisibility(View.GONE);
            vPlayer3.setVisibility(View.GONE);
        }


        //Initializing Up and Down Buttons
        Button btnUpPlayer1 = (Button) findViewById(R.id.btnUpPlayer1);
        Button btnUpPlayer2 = (Button) findViewById(R.id.btnUpPlayer2);
        Button btnUpPlayer3 = (Button) findViewById(R.id.btnUpPlayer3);
        Button btnUpPlayer4 = (Button) findViewById(R.id.btnUpPlayer4);
        Button btnUpPlayer5 = (Button) findViewById(R.id.btnUpPlayer5);
        Button btnUpPlayer6 = (Button) findViewById(R.id.btnUpPlayer6);
        Button btnUpPlayer7 = (Button) findViewById(R.id.btnUpPlayer1_2);
        Button btnUpPlayer8 = (Button) findViewById(R.id.btnUpPlayer2_2);

        Button btnDownPlayer1 = (Button) findViewById(R.id.btnDownPlayer1);
        Button btnDownPlayer2 = (Button) findViewById(R.id.btnDownPlayer2);
        Button btnDownPlayer3 = (Button) findViewById(R.id.btnDownPlayer3);
        Button btnDownPlayer4 = (Button) findViewById(R.id.btnDownPlayer4);
        Button btnDownPlayer5 = (Button) findViewById(R.id.btnDownPlayer5);
        Button btnDownPlayer6 = (Button) findViewById(R.id.btnDownPlayer6);
        Button btnDownPlayer7 = (Button) findViewById(R.id.btnDownPlayer1_2);
        Button btnDownPlayer8 = (Button) findViewById(R.id.btnDownPlayer2_2);


        //Setting onClick Listeners for health buttons
        btnUpPlayer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p1Counter++;
                txtPlayer1.setText(Integer.toString(p1Counter));
            }
        });
        btnUpPlayer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p2Counter++;
                txtPlayer2.setText(Integer.toString(p2Counter));
            }
        });
        btnUpPlayer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p3Counter++;
                txtPlayer3.setText(Integer.toString(p3Counter));
            }
        });
        btnUpPlayer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p4Counter++;
                txtPlayer4.setText(Integer.toString(p4Counter));
            }
        });
        btnUpPlayer5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p5Counter++;
                txtPlayer5.setText(Integer.toString(p5Counter));
            }
        });
        btnUpPlayer6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p6Counter++;
                txtPlayer6.setText(Integer.toString(p6Counter));
            }
        });
        btnUpPlayer7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p7Counter++;
                txtPlayer7.setText(Integer.toString(p7Counter));
            }
        });
        btnUpPlayer8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p8Counter++;
                txtPlayer8.setText(Integer.toString(p8Counter));
            }
        });

        btnDownPlayer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p1Counter--;
                txtPlayer1.setText(Integer.toString(p1Counter));
            }
        });
        btnDownPlayer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p2Counter--;
                txtPlayer2.setText(Integer.toString(p2Counter));
            }
        });
        btnDownPlayer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p3Counter--;
                txtPlayer3.setText(Integer.toString(p3Counter));
            }
        });
        btnDownPlayer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p4Counter--;
                txtPlayer4.setText(Integer.toString(p4Counter));
            }
        });
        btnDownPlayer5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p5Counter--;
                txtPlayer5.setText(Integer.toString(p5Counter));
            }
        });
        btnDownPlayer6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p6Counter--;
                txtPlayer6.setText(Integer.toString(p6Counter));
            }
        });
        btnDownPlayer7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p7Counter--;
                txtPlayer7.setText(Integer.toString(p7Counter));
            }
        });
        btnDownPlayer8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p8Counter--;
                txtPlayer8.setText(Integer.toString(p8Counter));
            }
        });


        //sets onLongCLick Listeners for the health buttons
        btnUpPlayer1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p1Counter = p1Counter + 10;
                txtPlayer1.setText(Integer.toString(p1Counter));
                return true;
            }
        });
        btnUpPlayer2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p2Counter = p2Counter + 10;
                txtPlayer2.setText(Integer.toString(p2Counter));
                return true;
            }
        });
        btnUpPlayer3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p3Counter = p3Counter + 10;
                txtPlayer3.setText(Integer.toString(p3Counter));
                return true;
            }
        });
        btnUpPlayer4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p4Counter = p4Counter + 10;
                txtPlayer4.setText(Integer.toString(p4Counter));
                return true;
            }
        });
        btnUpPlayer5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p5Counter = p5Counter + 10;
                txtPlayer5.setText(Integer.toString(p5Counter));
                return true;
            }
        });
        btnUpPlayer6.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p6Counter = p6Counter + 10;
                txtPlayer6.setText(Integer.toString(p6Counter));
                return true;
            }
        });
        btnUpPlayer7.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p7Counter = p7Counter + 10;
                txtPlayer7.setText(Integer.toString(p7Counter));
                return true;
            }
        });
        btnUpPlayer8.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p8Counter = p8Counter + 10;
                txtPlayer8.setText(Integer.toString(p8Counter));
                return true;
            }
        });
        btnDownPlayer1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p1Counter = p1Counter - 10;
                txtPlayer1.setText(Integer.toString(p1Counter));
                return true;
            }
        });
        btnDownPlayer2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p2Counter = p2Counter - 10;
                txtPlayer2.setText(Integer.toString(p2Counter));
                return true;
            }
        });
        btnDownPlayer3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p3Counter = p3Counter - 10;
                txtPlayer3.setText(Integer.toString(p3Counter));
                return true;
            }
        });
        btnDownPlayer4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p4Counter = p4Counter - 10;
                txtPlayer4.setText(Integer.toString(p4Counter));
                return true;
            }
        });
        btnDownPlayer5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p5Counter = p5Counter - 10;
                txtPlayer5.setText(Integer.toString(p5Counter));
                return true;
            }
        });
        btnDownPlayer6.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p6Counter = p6Counter - 10;
                txtPlayer6.setText(Integer.toString(p6Counter));
                return true;
            }
        });
        btnDownPlayer7.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p7Counter = p7Counter - 10;
                txtPlayer7.setText(Integer.toString(p7Counter));
                return true;
            }
        });
        btnDownPlayer8.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                p8Counter = p8Counter - 10;
                txtPlayer8.setText(Integer.toString(p8Counter));
                return true;
            }
        });


        //onClicks for Life Total TextViews

        txtPlayer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 1;
                showPlayerDialog(player);
            }
        });
        txtPlayer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 2;
                showPlayerDialog(player);
            }
        });
        txtPlayer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 3;
                showPlayerDialog(player);
            }
        });
        txtPlayer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 4;
                showPlayerDialog(player);
            }
        });
        txtPlayer5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 5;
                showPlayerDialog(player);
            }
        });
        txtPlayer6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 6;
                showPlayerDialog(player);
            }
        });
        txtPlayer7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 7;
                showPlayerDialog(player);
            }
        });
        txtPlayer8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player = 8;
                showPlayerDialog(player);
            }
        });
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            decorView.setSystemUiVisibility(hideSystemBars());
        }
    }

    private int hideSystemBars() {
        return View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
    }

    public void showPlayerDialog(int player) {
        final Dialog playerDialog = new Dialog(LifeCounterActivity.this);
        //Turns off the regular title
        playerDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Allows to close window by clicking outside of it
        playerDialog.setCancelable(true);
        //Links to the created custom dialog
        playerDialog.setContentView(R.layout.player_layout);

        final int[] playerId = {player};

        playerDialog.show();

        //Initializes PlayerDialog Buttons and Text
        Button btnBlack = playerDialog.findViewById(R.id.btnBlack);
        Button btnWhite = playerDialog.findViewById(R.id.btnWhite);
        Button btnRed = playerDialog.findViewById(R.id.btnRed);
        Button btnGreen = playerDialog.findViewById(R.id.btnGreen);
        Button btnYellow = playerDialog.findViewById(R.id.btnYellow);
        Button btnOrange = playerDialog.findViewById(R.id.btnOrange);
        Button btnBlue = playerDialog.findViewById(R.id.btnBlue);
        Button btnTeal = playerDialog.findViewById(R.id.btnTeal);
        Button btnPurple = playerDialog.findViewById(R.id.btnPurple);
        Button btnMagenta = playerDialog.findViewById(R.id.btnMagenta);
        Button btnPink = playerDialog.findViewById(R.id.btnPink);
        Button btnTurquoise = playerDialog.findViewById(R.id.btnTurquoise);

        View vCommander = playerDialog.findViewById(R.id.vCommanderView);
        View vCommander2 = playerDialog.findViewById(R.id.vCommanderView2);
        View vCommander3 = playerDialog.findViewById(R.id.vCommanderView3);
        View vCommander4 = playerDialog.findViewById(R.id.vCommanderView4);
        Button btnCommanderUp = playerDialog.findViewById(R.id.btnCommanderUp);
        Button btnCommanderUp2 = playerDialog.findViewById(R.id.btnCommanderUp2);
        Button btnCommanderUp3 = playerDialog.findViewById(R.id.btnCommanderUp3);
        Button btnCommanderUp4 = playerDialog.findViewById(R.id.btnCommanderUp4);
        Button btnCommanderDown = playerDialog.findViewById(R.id.btnCommanderDown);
        Button btnCommanderDown2 = playerDialog.findViewById(R.id.btnCommanderDown2);
        Button btnCommanderDown3 = playerDialog.findViewById(R.id.btnCommanderDown3);
        Button btnCommanderDown4 = playerDialog.findViewById(R.id.btnCommanderDown4);

        TextView txtInfect = playerDialog.findViewById(R.id.txtInfect);
        Button btnInfectUp = playerDialog.findViewById(R.id.btnInfectUp);
        Button btnInfectDown = playerDialog.findViewById(R.id.btnInfectDown);

        TextView txtEnergy = playerDialog.findViewById(R.id.txtEnergy);
        Button btnEnergyUp = playerDialog.findViewById(R.id.btnEnergyUp);
        Button btnEnergyDown = playerDialog.findViewById(R.id.btnEnergyDown);

        TextView txtStorm = playerDialog.findViewById(R.id.txtStorm);
        Button btnStormUp = playerDialog.findViewById(R.id.btnStormUp);
        Button btnStormDown = playerDialog.findViewById(R.id.btnStormDown);

        //Initializing player views
        LinearLayout vPlayer1 = findViewById(R.id.vPlayer1);
        LinearLayout vPlayer2 = findViewById(R.id.vPlayer2);
        LinearLayout vPlayer3 = findViewById(R.id.vPlayer3);
        LinearLayout vPlayer4 = findViewById(R.id.vPlayer4);
        LinearLayout vPlayer5 = findViewById(R.id.vPlayer5);
        LinearLayout vPlayer6 = findViewById(R.id.vPlayer6);
        LinearLayout vPlayer7 = findViewById(R.id.vh1_2);
        LinearLayout vPlayer8 = findViewById(R.id.vh2_2);

        //Initializing player texts
        TextView txtPlayer1 = findViewById(R.id.txtPlayer1);
        TextView txtPlayer2 = findViewById(R.id.txtPlayer2);
        TextView txtPlayer3 = findViewById(R.id.txtPlayer3);
        TextView txtPlayer4 = findViewById(R.id.txtPlayer4);
        TextView txtPlayer5 = findViewById(R.id.txtPlayer5);
        TextView txtPlayer6 = findViewById(R.id.txtPlayer6);
        TextView txtPlayer7 = findViewById(R.id.txtPlayer1_2);
        TextView txtPlayer8 = findViewById(R.id.txtPlayer2_2);

        TextView txtCommanderView = playerDialog.findViewById(R.id.txtCommander);
        TextView txtCommander2 = playerDialog.findViewById(R.id.txtCommander2);
        TextView txtCommander3 = playerDialog.findViewById(R.id.txtCommander3);
        TextView txtCommander4 = playerDialog.findViewById(R.id.txtCommander4);

        TextView txtCommanderOpen = playerDialog.findViewById(R.id.txtCommanderView);

        //onClicks for Color Buttons
        btnBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#000000"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer1.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer2.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer3.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer4.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer5.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer6.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer7.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    txtPlayer8.setTextColor(Color.parseColor("#000000"));
                }
            }
        });
        btnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#FF0000"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#139e23"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer1.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer2.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer3.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer4.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer5.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer6.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer7.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#ede734"));
                    txtPlayer8.setTextColor(Color.parseColor("#000000"));
                }
            }
        });
        btnOrange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#ed8309"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#0b16de"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnTeal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#08c6d4"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnPurple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#920bdb"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnMagenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#d408d4"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnPink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer1.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer2.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer3.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer4.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer5.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer6.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer7.setTextColor(Color.parseColor("#ffffff"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#f705b7"));
                    txtPlayer8.setTextColor(Color.parseColor("#ffffff"));
                }
            }
        });
        btnTurquoise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    vPlayer1.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer1.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 2) {
                    vPlayer2.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer2.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 3) {
                    vPlayer3.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer3.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 4) {
                    vPlayer4.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer4.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 5) {
                    vPlayer5.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer5.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 6) {
                    vPlayer6.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer6.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 7) {
                    vPlayer7.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer7.setTextColor(Color.parseColor("#000000"));
                }
                else if (playerId[0] == 8) {
                    vPlayer8.setBackgroundColor(Color.parseColor("#04dec1"));
                    txtPlayer8.setTextColor(Color.parseColor("#000000"));
                }
            }
        });

        //Sets up counters
        if (playerId[0] == 1) {
            txtCommanderView.setText(Integer.toString(p1Commander));
            txtCommander2.setText(Integer.toString(p1Commander2));
            txtCommander3.setText(Integer.toString(p1Commander3));
            txtCommander4.setText(Integer.toString(p1Commander4));
            txtInfect.setText(Integer.toString(p1Infect));
            txtEnergy.setText(Integer.toString(p1Energy));
            txtStorm.setText(Integer.toString(p1Storm));
        }
        else if (playerId[0] == 2) {
            txtCommanderView.setText(Integer.toString(p2Commander));
            txtCommander2.setText(Integer.toString(p2Commander2));
            txtCommander3.setText(Integer.toString(p2Commander3));
            txtCommander4.setText(Integer.toString(p2Commander4));
            txtInfect.setText(Integer.toString(p2Infect));
            txtEnergy.setText(Integer.toString(p2Energy));
            txtStorm.setText(Integer.toString(p2Storm));
        }
        else if (playerId[0] == 3) {
            txtCommanderView.setText(Integer.toString(p3Commander));
            txtCommander2.setText(Integer.toString(p3Commander2));
            txtCommander3.setText(Integer.toString(p3Commander3));
            txtCommander4.setText(Integer.toString(p3Commander4));
            txtInfect.setText(Integer.toString(p3Infect));
            txtEnergy.setText(Integer.toString(p3Energy));
            txtStorm.setText(Integer.toString(p3Storm));
        }
        else if (playerId[0] == 4) {
            txtCommanderView.setText(Integer.toString(p4Commander));
            txtCommander2.setText(Integer.toString(p4Commander2));
            txtCommander3.setText(Integer.toString(p4Commander3));
            txtCommander4.setText(Integer.toString(p4Commander4));
            txtInfect.setText(Integer.toString(p4Infect));
            txtEnergy.setText(Integer.toString(p4Energy));
            txtStorm.setText(Integer.toString(p4Storm));
        }
        else if (playerId[0] == 5) {
            txtCommanderView.setText(Integer.toString(p5Commander));
            txtCommander2.setText(Integer.toString(p5Commander2));
            txtCommander3.setText(Integer.toString(p5Commander3));
            txtCommander4.setText(Integer.toString(p5Commander4));
            txtInfect.setText(Integer.toString(p5Infect));
            txtEnergy.setText(Integer.toString(p5Energy));
            txtStorm.setText(Integer.toString(p5Storm));
        }
        else if (playerId[0] == 6) {
            txtCommanderView.setText(Integer.toString(p6Commander));
            txtCommander2.setText(Integer.toString(p6Commander2));
            txtCommander3.setText(Integer.toString(p6Commander3));
            txtCommander4.setText(Integer.toString(p6Commander4));
            txtInfect.setText(Integer.toString(p6Infect));
            txtEnergy.setText(Integer.toString(p6Energy));
            txtStorm.setText(Integer.toString(p6Storm));
        }
        else if (playerId[0] == 7) {
            txtCommanderView.setText(Integer.toString(p7Commander));
            txtCommander2.setText(Integer.toString(p7Commander2));
            txtCommander3.setText(Integer.toString(p7Commander3));
            txtCommander4.setText(Integer.toString(p7Commander4));
            txtInfect.setText(Integer.toString(p7Infect));
            txtEnergy.setText(Integer.toString(p7Energy));
            txtStorm.setText(Integer.toString(p7Storm));
        }
        else if (playerId[0] == 8) {
            txtCommanderView.setText(Integer.toString(p8Commander));
            txtCommander2.setText(Integer.toString(p8Commander2));
            txtCommander3.setText(Integer.toString(p8Commander3));
            txtCommander4.setText(Integer.toString(p8Commander4));
            txtInfect.setText(Integer.toString(p8Infect));
            txtEnergy.setText(Integer.toString(p8Energy));
            txtStorm.setText(Integer.toString(p8Storm));
        }

        btnCommanderUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander++;
                    txtCommanderView.setText(Integer.toString(p1Commander));
                }
                else if (playerId[0] == 2) {
                    p2Commander++;
                    txtCommanderView.setText(Integer.toString(p2Commander));
                }
                else if (playerId[0] == 3) {
                    p3Commander++;
                    txtCommanderView.setText(Integer.toString(p3Commander));
                }
                else if (playerId[0] == 4) {
                    p4Commander++;
                    txtCommanderView.setText(Integer.toString(p4Commander));
                }
                else if (playerId[0] == 5) {
                    p5Commander++;
                    txtCommanderView.setText(Integer.toString(p5Commander));
                }
                else if (playerId[0] == 6) {
                    p6Commander++;
                    txtCommanderView.setText(Integer.toString(p6Commander));
                }
                else if (playerId[0] == 7) {
                    p7Commander++;
                    txtCommanderView.setText(Integer.toString(p7Commander));
                }
                else if (playerId[0] == 8) {
                    p8Commander++;
                    txtCommanderView.setText(Integer.toString(p8Commander));
                }
            }
        });
        btnCommanderUp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander2++;
                    txtCommander2.setText(Integer.toString(p1Commander2));
                }
                else if (playerId[0] == 2) {
                    p2Commander2++;
                    txtCommander2.setText(Integer.toString(p2Commander2));
                }
                else if (playerId[0] == 3) {
                    p3Commander2++;
                    txtCommander2.setText(Integer.toString(p3Commander2));
                }
                else if (playerId[0] == 4) {
                    p4Commander2++;
                    txtCommander2.setText(Integer.toString(p4Commander2));
                }
                else if (playerId[0] == 5) {
                    p5Commander2++;
                    txtCommander2.setText(Integer.toString(p5Commander2));
                }
                else if (playerId[0] == 6) {
                    p6Commander2++;
                    txtCommander2.setText(Integer.toString(p6Commander2));
                }
                else if (playerId[0] == 7) {
                    p7Commander2++;
                    txtCommander2.setText(Integer.toString(p7Commander2));
                }
                else if (playerId[0] == 8) {
                    p8Commander2++;
                    txtCommander2.setText(Integer.toString(p8Commander2));
                }
            }
        });
        btnCommanderUp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander3++;
                    txtCommander3.setText(Integer.toString(p1Commander3));
                }
                else if (playerId[0] == 2) {
                    p2Commander3++;
                    txtCommander3.setText(Integer.toString(p2Commander3));
                }
                else if (playerId[0] == 3) {
                    p3Commander3++;
                    txtCommander3.setText(Integer.toString(p3Commander3));
                }
                else if (playerId[0] == 4) {
                    p4Commander3++;
                    txtCommander3.setText(Integer.toString(p4Commander3));
                }
                else if (playerId[0] == 5) {
                    p5Commander3++;
                    txtCommander3.setText(Integer.toString(p5Commander3));
                }
                else if (playerId[0] == 6) {
                    p6Commander3++;
                    txtCommander3.setText(Integer.toString(p6Commander3));
                }
                else if (playerId[0] == 7) {
                    p7Commander3++;
                    txtCommander3.setText(Integer.toString(p7Commander3));
                }
                else if (playerId[0] == 8) {
                    p8Commander3++;
                    txtCommander3.setText(Integer.toString(p8Commander3));
                }
            }
        });
        btnCommanderUp4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander4++;
                    txtCommander4.setText(Integer.toString(p1Commander4));
                }
                else if (playerId[0] == 2) {
                    p2Commander4++;
                    txtCommander4.setText(Integer.toString(p2Commander4));
                }
                else if (playerId[0] == 3) {
                    p3Commander4++;
                    txtCommander4.setText(Integer.toString(p3Commander4));
                }
                else if (playerId[0] == 4) {
                    p4Commander4++;
                    txtCommander4.setText(Integer.toString(p4Commander4));
                }
                else if (playerId[0] == 5) {
                    p5Commander4++;
                    txtCommander4.setText(Integer.toString(p5Commander4));
                }
                else if (playerId[0] == 6) {
                    p6Commander4++;
                    txtCommander4.setText(Integer.toString(p6Commander4));
                }
                else if (playerId[0] == 7) {
                    p7Commander4++;
                    txtCommander4.setText(Integer.toString(p7Commander4));
                }
                else if (playerId[0] == 8) {
                    p8Commander4++;
                    txtCommander4.setText(Integer.toString(p8Commander4));
                }
            }
        });
        btnCommanderDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander--;
                    txtCommanderView.setText(Integer.toString(p1Commander));
                }
                else if (playerId[0] == 2) {
                    p2Commander--;
                    txtCommanderView.setText(Integer.toString(p2Commander));
                }
                else if (playerId[0] == 3) {
                    p3Commander--;
                    txtCommanderView.setText(Integer.toString(p3Commander));
                }
                else if (playerId[0] == 4) {
                    p4Commander--;
                    txtCommanderView.setText(Integer.toString(p4Commander));
                }
                else if (playerId[0] == 5) {
                    p5Commander--;
                    txtCommanderView.setText(Integer.toString(p5Commander));
                }
                else if (playerId[0] == 6) {
                    p6Commander--;
                    txtCommanderView.setText(Integer.toString(p6Commander));
                }
                else if (playerId[0] == 7) {
                    p7Commander--;
                    txtCommanderView.setText(Integer.toString(p7Commander));
                }
                else if (playerId[0] == 8) {
                    p8Commander--;
                    txtCommanderView.setText(Integer.toString(p8Commander));
                }
            }
        });
        btnCommanderDown2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander2--;
                    txtCommander2.setText(Integer.toString(p1Commander2));
                }
                else if (playerId[0] == 2) {
                    p2Commander2--;
                    txtCommander2.setText(Integer.toString(p2Commander2));
                }
                else if (playerId[0] == 3) {
                    p3Commander2--;
                    txtCommander2.setText(Integer.toString(p3Commander2));
                }
                else if (playerId[0] == 4) {
                    p4Commander2--;
                    txtCommander2.setText(Integer.toString(p4Commander2));
                }
                else if (playerId[0] == 5) {
                    p5Commander2--;
                    txtCommander2.setText(Integer.toString(p5Commander2));
                }
                else if (playerId[0] == 6) {
                    p6Commander2--;
                    txtCommander2.setText(Integer.toString(p6Commander2));
                }
                else if (playerId[0] == 7) {
                    p7Commander2--;
                    txtCommander2.setText(Integer.toString(p7Commander2));
                }
                else if (playerId[0] == 8) {
                    p8Commander2--;
                    txtCommander2.setText(Integer.toString(p8Commander2));
                }
            }
        });
        btnCommanderDown3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander3--;
                    txtCommander3.setText(Integer.toString(p1Commander3));
                }
                else if (playerId[0] == 2) {
                    p2Commander3--;
                    txtCommander3.setText(Integer.toString(p2Commander3));
                }
                else if (playerId[0] == 3) {
                    p3Commander3--;
                    txtCommander3.setText(Integer.toString(p3Commander3));
                }
                else if (playerId[0] == 4) {
                    p4Commander3--;
                    txtCommander3.setText(Integer.toString(p4Commander3));
                }
                else if (playerId[0] == 5) {
                    p5Commander3--;
                    txtCommander3.setText(Integer.toString(p5Commander3));
                }
                else if (playerId[0] == 6) {
                    p6Commander3--;
                    txtCommander3.setText(Integer.toString(p6Commander3));
                }
                else if (playerId[0] == 7) {
                    p7Commander3--;
                    txtCommander3.setText(Integer.toString(p7Commander3));
                }
                else if (playerId[0] == 8) {
                    p8Commander3--;
                    txtCommander3.setText(Integer.toString(p8Commander3));
                }
            }
        });
        btnCommanderDown4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Commander4--;
                    txtCommander4.setText(Integer.toString(p1Commander4));
                }
                else if (playerId[0] == 2) {
                    p2Commander4--;
                    txtCommander4.setText(Integer.toString(p2Commander4));
                }
                else if (playerId[0] == 3) {
                    p3Commander4--;
                    txtCommander4.setText(Integer.toString(p3Commander4));
                }
                else if (playerId[0] == 4) {
                    p4Commander4--;
                    txtCommander4.setText(Integer.toString(p4Commander4));
                }
                else if (playerId[0] == 5) {
                    p5Commander4--;
                    txtCommander4.setText(Integer.toString(p5Commander4));
                }
                else if (playerId[0] == 6) {
                    p6Commander4--;
                    txtCommander4.setText(Integer.toString(p6Commander4));
                }
                else if (playerId[0] == 7) {
                    p7Commander4--;
                    txtCommander4.setText(Integer.toString(p7Commander4));
                }
                else if (playerId[0] == 8) {
                    p8Commander4--;
                    txtCommander4.setText(Integer.toString(p8Commander4));
                }
            }
        });
        btnInfectUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Infect++;
                    txtInfect.setText(Integer.toString(p1Infect));
                }
                else if (playerId[0] == 2) {
                    p2Infect++;
                    txtInfect.setText(Integer.toString(p2Infect));
                }
                else if (playerId[0] == 3) {
                    p3Infect++;
                    txtInfect.setText(Integer.toString(p3Infect));
                }
                else if (playerId[0] == 4) {
                    p4Infect++;
                    txtInfect.setText(Integer.toString(p4Infect));
                }
                else if (playerId[0] == 5) {
                    p5Infect++;
                    txtInfect.setText(Integer.toString(p5Infect));
                }
                else if (playerId[0] == 6) {
                    p6Infect++;
                    txtInfect.setText(Integer.toString(p6Infect));
                }
                else if (playerId[0] == 7) {
                    p7Infect++;
                    txtInfect.setText(Integer.toString(p7Infect));
                }
                else if (playerId[0] == 8) {
                    p8Infect++;
                    txtInfect.setText(Integer.toString(p8Infect));
                }
            }
        });
        btnInfectDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Infect--;
                    txtInfect.setText(Integer.toString(p1Infect));
                }
                else if (playerId[0] == 2) {
                    p2Infect--;
                    txtInfect.setText(Integer.toString(p2Infect));
                }
                else if (playerId[0] == 3) {
                    p3Infect--;
                    txtInfect.setText(Integer.toString(p3Infect));
                }
                else if (playerId[0] == 4) {
                    p4Infect--;
                    txtInfect.setText(Integer.toString(p4Infect));
                }
                else if (playerId[0] == 5) {
                    p5Infect--;
                    txtInfect.setText(Integer.toString(p5Infect));
                }
                else if (playerId[0] == 6) {
                    p6Infect--;
                    txtInfect.setText(Integer.toString(p6Infect));
                }
                else if (playerId[0] == 7) {
                    p7Infect--;
                    txtInfect.setText(Integer.toString(p7Infect));
                }
                else if (playerId[0] == 8) {
                    p8Infect--;
                    txtInfect.setText(Integer.toString(p8Infect));
                }
            }
        });
        btnEnergyUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Energy++;
                    txtEnergy.setText(Integer.toString(p1Energy));
                }
                else if (playerId[0] == 2) {
                    p2Energy++;
                    txtEnergy.setText(Integer.toString(p2Energy));
                }
                else if (playerId[0] == 3) {
                    p3Energy++;
                    txtEnergy.setText(Integer.toString(p3Energy));
                }
                else if (playerId[0] == 4) {
                    p4Energy++;
                    txtEnergy.setText(Integer.toString(p4Energy));
                }
                else if (playerId[0] == 5) {
                    p5Energy++;
                    txtEnergy.setText(Integer.toString(p5Energy));
                }
                else if (playerId[0] == 6) {
                    p6Energy++;
                    txtEnergy.setText(Integer.toString(p6Energy));
                }
                else if (playerId[0] == 7) {
                    p7Energy++;
                    txtEnergy.setText(Integer.toString(p7Energy));
                }
                else if (playerId[0] == 8) {
                    p8Energy++;
                    txtEnergy.setText(Integer.toString(p8Energy));
                }
            }
        });
        btnEnergyDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Energy--;
                    txtEnergy.setText(Integer.toString(p1Energy));
                }
                else if (playerId[0] == 2) {
                    p2Energy--;
                    txtEnergy.setText(Integer.toString(p2Energy));
                }
                else if (playerId[0] == 3) {
                    p3Energy--;
                    txtEnergy.setText(Integer.toString(p3Energy));
                }
                else if (playerId[0] == 4) {
                    p4Energy--;
                    txtEnergy.setText(Integer.toString(p4Energy));
                }
                else if (playerId[0] == 5) {
                    p5Energy--;
                    txtEnergy.setText(Integer.toString(p5Energy));
                }
                else if (playerId[0] == 6) {
                    p6Energy--;
                    txtEnergy.setText(Integer.toString(p6Energy));
                }
                else if (playerId[0] == 7) {
                    p7Energy--;
                    txtEnergy.setText(Integer.toString(p7Energy));
                }
                else if (playerId[0] == 8) {
                    p8Energy--;
                    txtEnergy.setText(Integer.toString(p8Energy));
                }
            }
        });
        btnStormUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Storm++;
                    txtStorm.setText(Integer.toString(p1Storm));
                }
                else if (playerId[0] == 2) {
                    p2Storm++;
                    txtStorm.setText(Integer.toString(p2Storm));
                }
                else if (playerId[0] == 3) {
                    p3Storm++;
                    txtStorm.setText(Integer.toString(p3Storm));
                }
                else if (playerId[0] == 4) {
                    p4Storm++;
                    txtStorm.setText(Integer.toString(p4Storm));
                }
                else if (playerId[0] == 5) {
                    p5Storm++;
                    txtStorm.setText(Integer.toString(p5Storm));
                }
                else if (playerId[0] == 6) {
                    p6Storm++;
                    txtStorm.setText(Integer.toString(p6Storm));
                }
                else if (playerId[0] == 7) {
                    p7Storm++;
                    txtStorm.setText(Integer.toString(p7Storm));
                }
                else if (playerId[0] == 8) {
                    p8Storm++;
                    txtStorm.setText(Integer.toString(p8Storm));
                }
            }
        });
        btnStormDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playerId[0] == 1) {
                    p1Storm--;
                    txtStorm.setText(Integer.toString(p1Storm));
                }
                else if (playerId[0] == 2) {
                    p2Storm--;
                    txtStorm.setText(Integer.toString(p2Storm));
                }
                else if (playerId[0] == 3) {
                    p3Storm--;
                    txtStorm.setText(Integer.toString(p3Storm));
                }
                else if (playerId[0] == 4) {
                    p4Storm--;
                    txtStorm.setText(Integer.toString(p4Storm));
                }
                else if (playerId[0] == 5) {
                    p5Storm--;
                    txtStorm.setText(Integer.toString(p5Storm));
                }
                else if (playerId[0] == 6) {
                    p6Storm--;
                    txtStorm.setText(Integer.toString(p6Storm));
                }
                else if (playerId[0] == 7) {
                    p7Storm--;
                    txtStorm.setText(Integer.toString(p7Storm));
                }
                else if (playerId[0] == 8) {
                    p8Storm--;
                    txtStorm.setText(Integer.toString(p8Storm));
                }
            }
        });

        txtCommanderOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vCommander2.setVisibility(View.VISIBLE);
                vCommander3.setVisibility(View.VISIBLE);
                vCommander4.setVisibility(View.VISIBLE);
            }
        });
    }
}
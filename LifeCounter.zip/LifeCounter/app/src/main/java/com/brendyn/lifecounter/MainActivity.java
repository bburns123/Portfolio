package com.brendyn.lifecounter;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class MainActivity extends AppCompatActivity {

String format;
String players;
String workings = "";
TextView txtOutput;
TextView txtWorkings;
boolean leftBracket = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //Initializes Buttons
        Button btnLifeCounter = (Button) findViewById(R.id.btnLifeCounter);
        Button btnCalc = (Button) findViewById(R.id.btnCalc);
        Button btnRules = (Button) findViewById(R.id.btnRules);

        //Sets onClick listeners
        btnLifeCounter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLifeCounterDialog();
            }
        });

        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCalcDialog();
            }
        });
    }


    void showLifeCounterDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        //Turns off the regular title
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Allows to close window by clicking outside of it
        dialog.setCancelable(true);
        //Links to the created custom dialog
        dialog.setContentView(R.layout.lifecounter_layout);

        //Initializes the views from the layout
        Spinner formatSpinner = dialog.findViewById(R.id.spnFormat);
        Spinner playersSpinner = dialog.findViewById(R.id.spnPlayers);
        Button btnPlay = dialog.findViewById(R.id.btnPlay);

        //Populates the spinner entries
        ArrayAdapter<String> formatAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Format));
        ArrayAdapter<String> playersAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Players));

        formatAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        playersAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        formatSpinner.setAdapter(formatAdapter);
        playersSpinner.setAdapter(playersAdapter);

        //Play Button
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                format = formatSpinner.getSelectedItem().toString();
                players = playersSpinner.getSelectedItem().toString();
                openLifeCounterActivity();
            }
        });

        dialog.show();
    }

    public void openLifeCounterActivity() {
        Intent intent = new Intent(this, LifeCounterActivity.class);
        intent.putExtra("format", format);
        intent.putExtra("players", players);
        startActivity(intent);
    }

    public void setWorkings(String givenValue) {
        workings = workings + givenValue;
        txtWorkings.setText(workings);
    }

    public void showCalcDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        //Turns off the regular title
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Allows to close window by clicking outside of it
        dialog.setCancelable(true);
        //Links to the created custom dialog
        dialog.setContentView(R.layout.calc_layout);


        //Initializes all of the buttons for the calc
        TextView txtOutput = dialog.findViewById(R.id.txtOutput);
        TextView txtWorkings = dialog.findViewById(R.id.txtOutput2);
        Button btnClearEverything = dialog.findViewById(R.id.btnClearEverything);
        Button btnBracket = dialog.findViewById(R.id.btnBracket);
        Button btnSquare = dialog.findViewById(R.id.btnSquare);
        Button btnDivide = dialog.findViewById(R.id.btnDivide);
        Button btn7 = dialog.findViewById(R.id.btn7);
        Button btn8 = dialog.findViewById(R.id.btn8);
        Button btn9 = dialog.findViewById(R.id.btn9);
        Button btnMulti = dialog.findViewById(R.id.btnMulti);
        Button btn4 = dialog.findViewById(R.id.btn4);
        Button btn5 = dialog.findViewById(R.id.btn5);
        Button btn6 = dialog.findViewById(R.id.btn6);
        Button btnSubtract = dialog.findViewById(R.id.btnSubtract);
        Button btn3 = dialog.findViewById(R.id.btn3);
        Button btn2 = dialog.findViewById(R.id.btn2);
        Button btn1 = dialog.findViewById(R.id.btn1);
        Button btnAddition = dialog.findViewById(R.id.btnAddition);
        Button btnPosNed = dialog.findViewById(R.id.btnPosNeg);
        Button btn0 = dialog.findViewById(R.id.btn0);
        Button btnDecimal = dialog.findViewById(R.id.btnDecimal);
        Button btnEquals = dialog.findViewById(R.id.btnEquals);

        //sets the onClickListeners for the buttons
        btnEquals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double result = null;
                ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");

                try {
                    result = (double)engine.eval(workings);
                } catch (ScriptException e) {}

                if(result != null)
                    txtOutput.setText(String.valueOf(result.doubleValue()));
            }
        });



        btnClearEverything.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = "";
                txtWorkings.setText(workings);
                txtOutput.setText("");
                leftBracket = true;
            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "0";
                txtWorkings.setText(workings);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "1";
                txtWorkings.setText(workings);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "2";
                txtWorkings.setText(workings);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "3";
                txtWorkings.setText(workings);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "4";
                txtWorkings.setText(workings);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "5";
                txtWorkings.setText(workings);
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "6";
                txtWorkings.setText(workings);
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "7";
                txtWorkings.setText(workings);
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "8";
                txtWorkings.setText(workings);
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "9";
                txtWorkings.setText(workings);
            }
        });
        btnAddition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "+";
                txtWorkings.setText(workings);
            }
        });
        btnSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "-";
                txtWorkings.setText(workings);
            }
        });
        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "*";
                txtWorkings.setText(workings);
            }
        });
        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + "/";
                txtWorkings.setText(workings);
            }
        });
        btnSquare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double result = null;
                ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");
                String pow = "Math.pow(" + workings + ","+ 2 +")";

                workings = workings + "^" + 2;
                txtWorkings.setText(workings);

                try {
                    result = (double)engine.eval(pow);
                } catch (ScriptException e) {}

                if(result != null)
                    txtOutput.setText(String.valueOf(result.doubleValue()));

            }
        });
        btnDecimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                workings = workings + ".";
                txtWorkings.setText(workings);
            }
        });

        btnBracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(leftBracket){
                    workings = workings + "(";
                    txtWorkings.setText(workings);
                    leftBracket = false;
                }
                else {
                    workings = workings + ")";
                    txtWorkings.setText(workings);
                    leftBracket = true;
                }
            }
        });

        dialog.show();
    }
}


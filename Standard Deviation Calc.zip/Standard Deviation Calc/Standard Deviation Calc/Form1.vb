﻿Imports System.Math
Public Class Form1
    Dim X As Decimal
    Dim U As Decimal
    Dim N As Decimal
    Dim Y As Decimal


    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim Data As Decimal


        Try
            Data = txtData.Text
            U = txtU.Text
            txtData.Focus()
            txtData.SelectAll()

        Catch ex As Exception
            MessageBox.Show("Please enter a numerical value!")
            txtData.SelectAll()
            txtData.Focus()
            Exit Sub
        End Try



        X += Data
        Y += (Data - U) ^ 2


        lstNumbers.Items.Add(Data)

    End Sub

    Private Sub btnCalc_Click_1(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim i, i2 As Decimal
        N = txtN.Text


        i = Y / N
        i2 = Sqrt(i)

        lblOutput.Text = i2
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        X = 0
        Y = 0
        txtN.Text = ""
        txtData.Text = ""
        txtU.Text = ""
        lstNumbers.Items.Clear()
        lblOutput.Text = ""

    End Sub
End Class
